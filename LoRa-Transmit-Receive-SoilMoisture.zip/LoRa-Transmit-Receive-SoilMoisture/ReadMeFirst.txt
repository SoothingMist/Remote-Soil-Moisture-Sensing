
See ReadMe-LoRa.pdf for more details.

The Uno code for the receiver is in LoRa-Receive-SoilMoisture.

The Uno code for the transmitter/sensor is in LoRa-Transmit-SoilMoisture.
