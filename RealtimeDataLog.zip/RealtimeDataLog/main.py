# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.

# https://blog.miguelgrinberg.com/post/dynamically-update-your-flask-web-pages-using-turbo-flask

import json
import random
import time
from datetime import datetime
from flask import Flask, Response, render_template, stream_with_context, request
from turbo_flask import Turbo

app = Flask(__name__)
turbo = Turbo(app)

random.seed()  # Initialize the random number generator
messagePosting = "" # These are the messages that are displayed

# List of sensors
sensorList =\
[
  {'name': 'x'},
  {'name': 'y'},
  {'name': 'z'}
]
sensorName = 'x' # The presently-selected sensor name

# Present data value and source sensor
load =\
[
  sensorName,
  0.0
]

# History of messages
# https://www.digitalocean.com/community/tutorials/how-to-use-web-forms-in-a-flask-application
messageList =\
[
  "< blank message >",
  "< blank message >",
  "< blank message >",
  "< blank message >",
  "< blank message >",
  "< blank message >",
  "< blank message >",
  "< blank message >",
  "< blank message >",
  "< blank message >",
  "< blank message >"
]

# Retrieves data values from various sensors, creates a new message for each
def getNextData():
  reading = int(random.random() * 100 * 100) / 100
  message = datetime.now().strftime('%Y-%m-%d %H:%M:%S') + "; x; " + str(reading)
  return reading, message

# Adds a message to the message-history and displays that history
def update_messages(message):
  with app.app_context():
    global messagePosting
    messageList.pop(0)
    messageList.append(message)
    messagePosting = ""
    for i in range(len(messageList)): messagePosting += "<p>" + messageList[i] + "</p>"
    turbo.push(turbo.replace(render_template('suggestions.html'), 'suggestions'))

# Displays the selected sensor's present data value
def update_load():
  with app.app_context():
    turbo.push(turbo.replace(render_template('loadavg.html'), 'load'))

# Shows the overall display
@app.route('/')
def index():
  return render_template('index.html', data = sensorList)

# Retrieves the selected sensor name from the dropdown list
@app.route("/test" , methods=['GET', 'POST'])
def test():
  global sensorName
  sensorName = request.form.get('comp_select')
  return render_template('index.html', data = sensorList)

# Plots the data from the selected sensor
@app.route('/chart-data')
def chart_data():
    def generate_random_data():
        i = 0
        while True:
            i += 1
            data, message = getNextData()
            update_messages(message)
            load[0] = sensorName
            load[1] = data
            update_load()
            json_data = json.dumps(
                #{'time': datetime.now().strftime('%Y-%m-%d %H:%M:%S'), 'value': random.random() * 100})
                {'time': i, 'value': data})
            yield f"data:{json_data}\n\n"
            time.sleep(1)

    response = Response(stream_with_context(generate_random_data()), mimetype="text/event-stream")
    response.headers["Cache-Control"] = "no-cache"
    response.headers["X-Accel-Buffering"] = "no"
    return response

# For showing the present value of the selected sensor
@app.context_processor
def inject_load():
  return {'load0': load[0], 'load1': load[1]}

# For displaying the message history
@app.context_processor
def inject_messages():
  return {'suggestions': messageList}

# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    app.run(debug=True, threaded=True)

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
