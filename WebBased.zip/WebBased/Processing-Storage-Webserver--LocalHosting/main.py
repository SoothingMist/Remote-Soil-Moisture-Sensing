
import json
import random
import time
from flask import Flask, Response, render_template, stream_with_context, request
from flask_socketio import SocketIO, emit

# Pulls in the class for serial connection and message parsing
# https://stackoverflow.com/questions/4142151/how-to-import-the-class-within-the-same-directory-or-sub-directory
# https://realpython.com/python-sockets/#echo-server
from MessageParserClass import MessageParserClass
INET_HOST = "127.0.0.1" # Network address from which data is received, this one is localhost
INET_PORT = 65432 # Port to listen on (non-privileged ports are > 1023)

MessageParserObject = None # instance of MessageParserClass - Generates debugger warning, it is ok though
messagePosting = "" # These are the messages that are displayed

# Set this variable to "threading", "eventlet" or "gevent" to test the
# different async modes, or leave it set to None for the application to choose
# the best option based on installed packages.
async_mode = None

app = Flask(__name__)
socketio = SocketIO(app, async_mode = async_mode)

random.seed()  # Initialize the random number generator

# List of sensors
sensorList =\
[
  {'name': 'A1'},
  {'name': 'A3'},
  {'name': 'BAT'}
]
# https://www.w3schools.com/python/python_dictionaries.asp
sensorName = sensorList[1]['name'] # The presently-selected sensor name

# History of messages
# https://www.digitalocean.com/community/tutorials/how-to-use-web-forms-in-a-flask-application
messageList =\
[
  " blank message ",
  " blank message ",
  " blank message ",
  " blank message ",
  " blank message ",
  " blank message ",
  " blank message ",
  " blank message ",
  " blank message ",
  " blank message ",
  " blank message "
]

# Adds a message to the message-history and displays that history
def updateMessages(message):
    global messagePosting
    messageList.pop(0)
    messageList.append(message)
    messagePosting = ""
    for i in range(len(messageList)): messagePosting += messageList[i] + "<br>"

# Runs once before the first request
# https://pythonise.com/series/learning-flask/python-before-after-request
@app.before_first_request
def before_first_request_func():
  global MessageParserObject
  MessageParserObject = MessageParserClass(INET_HOST, INET_PORT) # instance of MessageParserClass
  updateMessages(messageList[0])

# Shows the overall display
@app.route('/')
def index():
  return render_template('index.html',
                         selectedSensor = sensorName,
                         sensorDictionary = sensorList,
                         messageHistory = messagePosting,
                         async_mode = socketio.async_mode)

@app.route('/chart-data')
def chart_data():
    def generate_random_data():
        global MessageParserObject
        t = -1
        while True:
            time.sleep(2)
            message = MessageParserObject.GetNextMessage()
            if message != "":
              updateMessages(message)
              socketio.emit('update_message_history', {'message_history': messagePosting})
              data = MessageParserObject.ExtractSensorData(sensorName)
              #data = random.random()
              if data is not None:
                t += 1 # increment time tick
                socketio.emit('update_sensor_value', {'sensor_msg': sensorName + ": " + str(data)})
                json_data = json.dumps(
                  #{'time': datetime.now().strftime('%Y-%m-%d %H:%M:%S'), 'value': random.random() * 100})
                  {'time': str(t), 'value': data})
                yield f"data:{json_data}\n\n"

    response = Response(stream_with_context(generate_random_data()), mimetype="text/event-stream")
    response.headers["Cache-Control"] = "no-cache"
    response.headers["X-Accel-Buffering"] = "no"
    return response

@socketio.event
def connect():
  updateMessages('Connected to server')
  emit('update_message_history', {'message_history': messagePosting})

@app.route("/selectSensor" , methods=['GET', 'POST'])
def selectSensor():
  global sensorName
  sensorName = request.form.get('comp_select')
  return render_template('index.html',
                         selectedSensor = sensorName,
                         sensorDictionary = sensorList,
                         messageHistory = messagePosting,
                         async_mode = socketio.async_mode)

if __name__ == '__main__':
  #app.run(debug=True, threaded=True)
  socketio.run(app)
