# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.

# References:
# https://realpython.com/python-sockets/#echo-client
# https://realpython.com/python-sockets/#echo-server
# https://eli.thegreenplace.net/2009/07/30/setting-up-python-to-work-with-the-serial-port

import serial
import socket

INET_HOST = "127.0.0.1"  # The server's hostname or IP address
INET_PORT = 65432  # The port used by the server
SERIAL_PORT = "COM4" # Serial port to listen on
SERIAL_BAUD = 9600   # Baud rate of the client

# Press the green button in the gutter to run the script.
if __name__ == '__main__':

  # Connect to a serial port.
  try: serial_connection = serial.Serial(SERIAL_PORT, SERIAL_BAUD, timeout=2)
  except BaseException as Error: # https://docs.python.org/3/tutorial/errors.html
    serial_connection = None
    print(f"Error opening serial port: {Error}, {type(Error)=}")
    raise

  # Receive and repeat serial messages from Arduino
  # for m in range(0,50):
  #   message = None
  #   if serial_connection is not None:
  #     message = serial_connection.read(1024).decode('ascii') # https://stackoverflow.com/questions/17615414/how-to-convert-binary-string-to-normal-string-in-python3
  #     if message is not None: print(message)

  # Send Arduino messages to a network address.
  try:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as inet_socket:
      inet_socket.connect((INET_HOST, INET_PORT))
      print("Connected with network address: ", str(INET_HOST), "  port: ", str(INET_PORT))

      # Receive and repeat serial messages from Arduino
      #for m in range(0,50):
      while True:
        message = None
        if serial_connection is not None:
          message = serial_connection.read(1024) # https://stackoverflow.com/questions/17615414/how-to-convert-binary-string-to-normal-string-in-python3
          if message is not None:
            print(message.decode('ascii'))
            inet_socket.sendall(message)
                  
      inet_socket.close() # https://docs.python.org/3/library/socket.html#example
      inet_socket = None
      serial_connection.close()
      serial_connection = None

  except BaseException as Error: # https://docs.python.org/3/tutorial/errors.html
    inet_socket = None
    print(f"Error working with network address/port: {Error}, {type(Error)=}")
    raise

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
