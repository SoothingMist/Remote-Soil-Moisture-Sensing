
These two modules constitute client/server testing where both reside on the internet. 

Either the client or the server can be started first. Once the system is running, either can be terminated and restarted without having to restart the other.

Open a console to the target directory and then use  python main.py  to start the process. The client will send a message to the server and then disconnect. The server receives the message and then also disconnects. Both then reconnect.

The application at hand, precision irrigation, only sends a message every six hours or so. This is not a streaming application.

There are still opportunities for the server to miss messages. However, a missed message now and then will not be critical to this application. For instance, the server could go down after connecting with the client but before the client's message is received. One could compensate by having the server check for sequential message IDs and then requesting a message to be resent if one is missed.

