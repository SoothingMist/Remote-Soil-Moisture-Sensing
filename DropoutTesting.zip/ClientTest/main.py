
# References:
# https://realpython.com/python-sockets/#echo-client
# https://realpython.com/python-sockets/#echo-server
# https://eli.thegreenplace.net/2009/07/30/setting-up-python-to-work-with-the-serial-port

import time
import socket
import os

INET_HOST = "192.168.1.160"  # The server's hostname or IP address
INET_PORT = 65432            # The port used by the server
SERIAL_PORT = "COM4" # Serial port used by the receiver
SERIAL_BAUD = 9600   # Baud rate of the receiver

if __name__ == '__main__':

  # Connect to the serial port on localhost being used by the receiver.
  # The receiver must first be connected to this port on localhost.
  # try: serial_connection = serial.Serial(SERIAL_PORT, SERIAL_BAUD, timeout=2)
  # except BaseException as Error: # https://docs.python.org/3/tutorial/errors.html
  #   serial_connection = None
  #   print(f"Error opening serial port: {Error}, {type(Error)=}")
  #   print("Receiver is likely not connected.")
  #   raise

  messageID = 0
  while True:
    # Connect to server
    inet_socket = None
    while inet_socket is None:
      try:
        # Connect to basestation.
        inet_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        #inet_socket.setblocking(0)
        inet_socket.connect((INET_HOST, INET_PORT))
        print("Connected with network address: ", str(INET_HOST), "  port: ", str(INET_PORT))
      except BaseException as Error:  # https://docs.python.org/3/tutorial/errors.html
        inet_socket = None
        print(f"\nError working with network address/port: {Error}, {type(Error)=}")
        print("It is likely that the server is not running yet.")

    # Send message to the server.
    messageID += 1
    message = "Message # " + str(messageID)
    try:
      inet_socket.sendall(message.encode('ascii'))
      print("Sent Message: " + message)
      time.sleep(5) # might be better to wait for an acknowledging message
      inet_socket.shutdown(socket.SHUT_RDWR) # https://stackoverflow.com/questions/409783/socket-shutdown-vs-socket-close
      inet_socket.close() # https://docs.python.org/3/library/socket.html#example
      inet_socket = None
    except ConnectionAbortedError as exceptionError:
      print(exceptionError)
      print("Connection aborted by server. Waiting for reconnect.")
