# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.

# Derived from https://instructobit.com/tutorial/101/Reconnect-a-Python-socket-after-it-has-lost-its-connection

import socket
from time import sleep

# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    # create and configure socket on local host
    serverSocket = socket.socket()
    host = socket.gethostname()
    port = 25000  # arbitrary port
    serverSocket.bind((host, port))
    print("My Host:Port: ", host, ":", port)
    serverSocket.listen(1)

    print("Waiting for client to connect")
    con, addr = serverSocket.accept()
    print("Connected to client")

    while True:
        # send wave to client
        con.send(bytes("Server wave", "UTF-8"))

        # receive wave from client
        try:
            message = con.recv(1024).decode("UTF-8")
            print(message)
        except ConnectionAbortedError as exceptionError:
            print("Connection aborted by client. Waiting for reconnect.")
            serverSocket.listen(1)
            con, addr = serverSocket.accept()

        # wait 1 second
        sleep(1)

    con.close();

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
