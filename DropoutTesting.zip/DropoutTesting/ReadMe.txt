
These two modules constitute client/server testing where the server is on localhost.
See the tutorial at https://instructobit.com/tutorial/101/Reconnect-a-Python-socket-after-it-has-lost-its-connection for the basic idea. The code has modifications so that either the client or the server can be started first. Once the system is running, either can be terminated and restarted without having to restart the other.

Open a console to the target directory and then use  python main.py  to start the process.

This approach has not yet been integrated into the main system since it has only been shown to work when both client and server are connected to localhost.

