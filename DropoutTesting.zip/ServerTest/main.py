
# Server
# Derived from https://instructobit.com/tutorial/101/Reconnect-a-Python-socket-after-it-has-lost-its-connection

import socket
from time import sleep
import sys

if __name__ == '__main__':

    # Set address and port of server
    # To find via Windows Command Console:
    # https://www.sas.upenn.edu/~jasonrw/HowTo-FindIP.htm#:~:text=From%20the%20desktop%2C%20navigate%20through%3B%20Start%20%3E%20Run%3E%20type,by%20Windows%20will%20be%20displayed.
    # Windows: ipconfig /all. Then see the entry under IPv4 Address.
    # Linux: ipconfig. Then see inet under wlp8so.
    INET_HOST = "192.168.1.178"
    INET_PORT = 65432

    while True:
      # create and configure socket.
      # Connect to a network address from which data is to be received
      # https://realpython.com/python-sockets/#echo-server
      socketName = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
      socketName.bind((INET_HOST, INET_PORT))
      socketName.listen()
      print("Waiting for PC_to_Arduino_Bridge connection (", str(INET_HOST), ":", str(INET_PORT), ")", flush = True)
      connection, address = socketName.accept()
      print("Connected by ", str(address), flush = True)

      # Get one message
      if connection is not None:
        try:
          dataBuffer = connection.recv(2048)
          dataBuffer = dataBuffer.decode("ascii")
          print(dataBuffer)
          connection.close()
          connection = None
        except socket.error:
          e = sys.exc_info()[0]
          print("Error: ", e)
