
# Server
# Derived from:
#   https://instructobit.com/tutorial/101/Reconnect-a-Python-socket-after-it-has-lost-its-connection
#   https://www.geeksforgeeks.org/socket-programming-python/#:~:text=Socket%20programming%20is%20a%20way,reaches%20out%20to%20the%20server.

import socket
from time import sleep
import sys

INET_PORT = 65432 # open this port to incoming network traffic

if __name__ == '__main__':

    # Set address and port of server
    # To find via Windows Command Console:
    # https://www.sas.upenn.edu/~jasonrw/HowTo-FindIP.htm#:~:text=From%20the%20desktop%2C%20navigate%20through%3B%20Start%20%3E%20Run%3E%20type,by%20Windows%20will%20be%20displayed.
    # Windows: ipconfig /all. Then see the entry under IPv4 Address.
    # Linux: ipconfig. Then see inet under wlp8so.

    while True:
      # create and configure socket.
      # Connect to a network address from which data is to be received
      # https://realpython.com/python-sockets/#echo-server
      inet_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
      inet_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1) # https://stackoverflow.com/questions/6380057/python-binding-socket-address-already-in-use
      inet_socket.bind(('', INET_PORT))
      inet_socket.listen()
      print("Waiting for PC_to_Arduino_Bridge connection to myself: (", str(socket.gethostname()), ":", str(INET_PORT), ")", flush = True)
      connection, address = inet_socket.accept()
      print("Connection From ", str(address), flush = True)

      # Get one message
      if connection is not None:
        try:
          dataBuffer = connection.recv(2048)
          dataBuffer = dataBuffer.decode("ascii")
          print(dataBuffer)
          connection.close()
          connection = None
          #inet_socket.shutdown(socket.SHUT_RDWR) # https://stackoverflow.com/questions/409783/socket-shutdown-vs-socket-close
          #inet_socket.close() # https://docs.python.org/3/library/socket.html#example
          inet_socket= None
        except socket.error:
          e = sys.exc_info()[0]
          print("Error: ", e)
