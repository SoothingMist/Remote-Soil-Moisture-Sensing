

// Original: https://www.youtube.com/watch?v=8BWjyZxGr5o
// https://github.com/ZainUlMustafa/Connect-And-Use-Arduino-via-Cpp-Software-Made-In-Any-IDE

#include "messageparser.h"

#include <iostream>

#include<stdlib.h>

#include"SerialPort.h" // open-access dependency, fully present

string MessageParser::getPortErrorMsg() { return portErrorMsg; }

MessageParser::MessageParser(const char *port)
{
    incomingData = NULL;
    message = "";
    msgBegin = 0;
    msgEnd = 0;
    portError = 0;
    portErrorMsg = "";
    arduino = NULL;
    portName = port;

    // Connect to a serial port.
    arduino = new SerialPort(port);
    if(arduino->isConnected())
    {
        portError = 0;
        portErrorMsg = "MessageParser::MessageParser -- Connection made with port: ";
        portErrorMsg += port;
    }
    else
    {
        portError = 1;
        portErrorMsg =  "MessageParser::MessageParser -- Error with port connection: ";
        portErrorMsg += port;
        portErrorMsg += " No connection made.";
    }
}

double MessageParser::ReadSensorData()
{
  GetNextMessage();
  if(portError == 0)
  {
    if(portErrorMsg.length() > 0)
    {
      // get numeric data from the extracted message
      // parse message, extract sample value
      // return that value
      msgBegin = portErrorMsg.find(':', 0);
      msgEnd = portErrorMsg.find(":", msgBegin + 1);
      portErrorMsg = portErrorMsg.substr(msgBegin + 1, msgEnd - msgBegin - 1);
      return stod(portErrorMsg);
    }
    else return NAN;
  }
  else return NAN;
}

void MessageParser::GetNextMessage()
{
    // Read incoming data, extract parsable message, use those messages
    portErrorMsg = "";
    if(arduino->isConnected())
    {
        portError = 0;
        incomingData = (char*)calloc(1, maxMsgSize);
        arduino->readSerialPort(incomingData, maxMsgSize); // read what is present at the port
        if (strlen(incomingData) > 0)
        {
            message += incomingData; // add port data to the message
        }
        if(message.length() > 0)
        {
            if ((msgEnd = message.find(":END")) != std::string::npos) // check for complete message
            {
                if ((msgBegin = message.substr(0, msgEnd).rfind("PGR-")) != std::string::npos)
                {
                    // Extract a complete message from those buffered.
                    portErrorMsg = message.substr(msgBegin, (msgEnd + 4) - msgBegin);

                    // Remove the extracted message from the buffer
                    message = message.substr(msgEnd + 4, message.length());
                }
                else
                {
                    // Delete incomplete messages
                    message = message.substr(msgEnd + 4, message.length());
                }
            }
          }
          else portErrorMsg = "";

          // empty the incoming-data buffer, don't want to leave junk laying around
          free(incomingData);
          incomingData = NULL;
        }
        else
        {
          portError = 1;
          portErrorMsg = "MessageParser::GetNextMessage -- Port " + portName + " no longer connected.";
        }
}

MessageParser::~MessageParser()
{
  if(arduino != NULL)
  {
    delete arduino;
    arduino = NULL;
  }

  if(incomingData != NULL)
  {
    free(incomingData);
    incomingData = NULL;
  }
}
