#ifndef MESSAGEPARSER_H
#define MESSAGEPARSER_H

#include<string>
using namespace std;

#include"SerialPort.h" // open-access dependency, fully present

// maximum size of character arrays having fixed sizes
#define maxMsgSize 1000

class MessageParser
{
public:

    // change the name of the port with the port name of your computer.
    // must remember that the backslashes are essential so do not remove them.
    // use the arduino IDE to discover the correct comm port.
    // example:
    // string port = "\\\\.\\COM8";
    explicit MessageParser(const char*);

    ~MessageParser();

    double ReadSensorData();
    string getPortErrorMsg();

private:

    char *incomingData; // message buffer

    // message support
    string message;
    size_t msgBegin;
    size_t msgEnd;
    void GetNextMessage();

    // serial port
    SerialPort *arduino;
    int portError;
    string portErrorMsg;
    string portName;
};

#endif // MESSAGEPARSER_H
