

// Original: https://www.youtube.com/watch?v=8BWjyZxGr5o
// https://github.com/ZainUlMustafa/Connect-And-Use-Arduino-via-Cpp-Software-Made-In-Any-IDE

#include <iostream>
#include <stdlib.h>

#include "messageparser.h"

#include"SerialPort.h" // open-access dependency, fully present

string MessageParser::getPortErrorMsg() { return portErrorMsg; }

MessageParser::MessageParser(const char *port)
{
    incomingData = NULL;
    message = "";
    msgBegin = 0;
    msgEnd = 0;
    portErrorMsg = "";
    arduino = NULL;
    portName = port;

    // Connect to a serial port.
    arduino = new SerialPort(port);
    if(arduino->isConnected())
    {
        portErrorMsg = "MessageParser::MessageParser -- Connection made with port:\n";
        portErrorMsg += port;
    }
    else
    {
        portErrorMsg =  "Error: MessageParser::MessageParser -- Error with port connection:\n";
        portErrorMsg += port;
        portErrorMsg += "\nNo connection made.";
    }
}

double MessageParser::ExtractSensorData(char* sensorID)
{
    double returnValue = NAN;
    if(portErrorMsg.find("Error:") == string::npos)
    {
      if(portErrorMsg.length() > 0)
      {
        // get the sensorID from the extracted message
        msgBegin = portErrorMsg.find('-', 0);
        msgBegin = portErrorMsg.find('-', msgBegin + 1);
        msgEnd = portErrorMsg.find("-", msgBegin + 1);
        if(portErrorMsg.substr(msgBegin + 1, msgEnd - msgBegin - 1).find(sensorID) != string::npos)
        {
          // get numeric data from the extracted message
          // parse message, extract sample value
          // return that value
          msgBegin = portErrorMsg.find(':', msgEnd + 1);
          msgEnd = portErrorMsg.find(":", msgBegin + 1);
          portErrorMsg = portErrorMsg.substr(msgBegin + 1, msgEnd - msgBegin - 1);
          returnValue = stod(portErrorMsg);
        }
      }
    }
    return returnValue;
}

void MessageParser::GetNextMessage()
{
    // Read incoming data, extract parsable message, use those messages
    portErrorMsg = "";
    if(arduino->isConnected())
    {
        incomingData = (char*)calloc(1, maxMsgSize);
        arduino->readSerialPort(incomingData, maxMsgSize); // read what is present at the port
        if (strlen(incomingData) > 0)
        {
            message += incomingData; // add port data to the message
        }
        if(message.length() > 0)
        {
            if ((msgEnd = message.find(":END")) != std::string::npos) // check for complete message
            {
                if ((msgBegin = message.substr(0, msgEnd).rfind("PGR-")) != std::string::npos)
                {
                    // Extract a complete message from those buffered.
                    portErrorMsg = message.substr(msgBegin, (msgEnd + 4) - msgBegin);

                    // Remove the extracted message from the buffer
                    message = message.substr(msgEnd + 4, message.length());
                }
                else
                {
                    // Delete incomplete messages
                    message = message.substr(msgEnd + 4, message.length());
                }
            }
          }

          // empty the incoming-data buffer, don't want to leave junk laying around
          free(incomingData);
          incomingData = NULL;
        }
        else
        {
          portErrorMsg = "Error: MessageParser::GetNextMessage -- Port " + portName + " no longer connected.";
        }
}

MessageParser::~MessageParser()
{
  if(arduino != NULL)
  {
    delete arduino;
    arduino = NULL;
  }

  if(incomingData != NULL)
  {
    free(incomingData);
    incomingData = NULL;
  }
}
