
# Demonstrates a server listening on a serial port
# https://eli.thegreenplace.net/2009/07/30/setting-up-python-to-work-with-the-serial-port

# https://stackoverflow.com/questions/4142151/how-to-import-the-class-within-the-same-directory-or-sub-directory
from MessageParserClass import MessageParser

import time

PORT = "COM4" # Serial port to listen on
BAUD = 9600   # Baud rate of the client

if __name__ == '__main__':
    messageParser = MessageParser(PORT, BAUD)
    sensorID = ""
    sensorData = ""
    while sensorID != "STOP":
      messageParser.GetNextMessage()
      messageParser.EchoCurrentMessage()
      sensorID, sensorData = messageParser.ExtractSensorData()
      print("ID: ", sensorID, "  Value: ", sensorData, flush = True)
      time.sleep(0.5) # necessary for internal electronics to have time to operate
    messageParser.CloseConnection()
    messageParser = None
