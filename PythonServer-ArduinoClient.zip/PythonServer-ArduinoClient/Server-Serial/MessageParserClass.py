
import serial

# Define a class to open/close an address/port and to parse messages.
# https://www.w3schools.com/python/python_classes.asp
# https://docs.python.org/3/tutorial/classes.html
# https://eli.thegreenplace.net/2009/07/30/setting-up-python-to-work-with-the-serial-port

class MessageParser:

  # Class creator/initializer
  def __init__(self, port, baud): # creator

    # Initialize variables
    self._incomingData = ""
    self._message = ""
    self._portName = port
    self._baudRate = baud
    self._connection = None

    # Connect to a serial port.
    try: self._connection = serial.Serial(self._portName, self._baudRate, timeout=0)
    except BaseException as Error: # https://docs.python.org/3/tutorial/errors.html
      self._connection = None
      print(f"MessageParser:init -- Error opening address/port: {Error}, {type(Error)=}")
      raise

  def GetNextMessage(self): # receives a binary string, returns an ascii string
    self._message = ""
    if self._connection is not None:
      self._incomingData += self._connection.read(1024).decode('ascii') # https://stackoverflow.com/questions/17615414/how-to-convert-binary-string-to-normal-string-in-python3
      if len(self._incomingData) > 0:
        msgEnd = self._incomingData.find(":END")
        if msgEnd > -1:
          msgBegin = self._incomingData.find("PGR-", 0, msgEnd)
          if msgBegin > -1: self._message = self._incomingData[msgBegin : msgEnd + 4] # https://www.freecodecamp.org/news/how-to-substring-a-string-in-python
          self._incomingData = self._incomingData[msgEnd + 4 : len(self._incomingData) - 1]

  def EchoCurrentMessage(self): # message is an ascii string, sends a binary string
    print(f"Current message is: {self._message}", flush = True)

  def ExtractSensorData(self):
    sensorID = None
    sensorData = None
    if len(self._message) > 0:
      # get the sensorID from the current message
      msgBegin = self._message.find('-', 0)
      msgBegin = self._message.find('-', msgBegin + 1);
      msgEnd = self._message.find("-", msgBegin + 1);
      sensorID = self._message[msgBegin + 1 : msgEnd]
      # get numeric data from the extracted message
      msgBegin = self._message.find(':', msgEnd + 1)
      msgEnd = self._message.find(":", msgBegin + 1)
      sensorData = self._message[msgBegin + 1 : msgEnd]
    # return the sensorID and sensorData
    return sensorID, sensorData

  def CloseConnection(self):
    self._connection.close()
    self._connection = None
    self._incomingData = None
    self._message = None
    self._portName = None
    self._baudRate = None
