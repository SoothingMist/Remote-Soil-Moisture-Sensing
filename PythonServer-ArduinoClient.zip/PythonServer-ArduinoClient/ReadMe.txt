
Please see the ReadMe within https://github.com/SoothingMist/Remote-Soil-Moisture-Sensing/blob/main/LoRa-Transmit-Receive-SoilMoisture-Serial_TwoCapacitiveSensors.zip. That will explain more about the arduino side of things.

For the python side: Open your command console to the python server. Then run python main.py. You can run the arduino client before or after the python server.

This client/server uses the com port. Look at arduino's serial monitor to see which port to use. main.py shows how to set the server's port and baud rate.

